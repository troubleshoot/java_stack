public class FizzBuzzTest{
  public static void main(String[] args){
    FizzBuzz f = new FizzBuzz();
    String dwad = f.fizzBuzz(8);
    System.out.println(dwad);
  }
}