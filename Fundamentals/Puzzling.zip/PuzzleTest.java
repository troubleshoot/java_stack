import java.util.ArrayList;
import java.util.Arrays;
public class PuzzleTest {
	public static void main(String[] args){
    Puzzle p = new Puzzle();
    // ArrayList<Integer> sumarr = p.sumArr();
    // ArrayList<String> namearr = p.nameArr();
    // p.alphabetWork();
    // int[] randarr = p.randArr();
    // int[] sortedrandarr = p.sortedRandArr();
    // String randstr = p.randStr();
    String[] randstrArr = p.randStrArr();
	}
}