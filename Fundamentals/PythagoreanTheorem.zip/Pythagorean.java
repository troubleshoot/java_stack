public class Pythagorean {
  public static void main(String[] args){
    PythagoreanTheorem p = new PythagoreanTheorem();
    double hypotenuse = p.calculateHypotenuse(5,5);
    System.out.println(hypotenuse);
  }
}