import java.util.ArrayList;
import java.util.Arrays;
public class BasicsTest{
	public static void main(String[] args){
		Basics b = new Basics();
		// boolean basic1 = b.oneTo255();
		// boolean odds = b.oddsTo255();
		// boolean sum = b.printSum();
    Integer[] myArray = new Integer[]{1, 5, 10, 7, -2};
		// boolean arr =  b.iterateArray(myArray);
		// int findmax = b.findMax(myArray);
		// int getavg = b.getAverage(myArray);
		// ArrayList<Integer> y = b.oddsArray();
		// int greater = b.greaterThanY(myArray, 5);
		// Integer[] squares = b.squareArray(myArray);
    // Integer[] positives = b.eliminateNegatives(myArray);
		// Integer[] mma = b.minMaxAvg(myArray);
		// Integer[] shift = b.shiftValues(myArray);
	}
}